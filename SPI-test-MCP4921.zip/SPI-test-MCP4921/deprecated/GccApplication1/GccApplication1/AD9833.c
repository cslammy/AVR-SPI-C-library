/*
 * GccApplication1.c
 *
 * Created: 2/23/2021 3:13:39 PM
 * Author : clamm
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

