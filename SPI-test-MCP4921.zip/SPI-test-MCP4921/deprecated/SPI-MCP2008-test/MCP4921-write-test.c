/*
 * SPI-MCP2008-test.c
 *  control MCP4921 SPI DA converter
 * Created: 2/22/2021 3:36:00 PM
 * 
 */ 
#define F_CPU 16000000UL
#define BAUD 9600
#define BAUD_TOL 2

#include <avr/io.h>
#include "spi3.h"
#include "stdio_setup.h"

void Delay(void);

int main(void)
{
    UartInit();

	
    while (1) 
    {
		SELECT();
	   	//Delay();
         	
        init_spi_master();
        spi_mode(0);
		SPI_Transfer(0b01110110); // write to DAC; buffer out; normal gain; no shutdown; MSB nibble is 0
		SPI_Transfer(0xFF); //write the rest.

		DESELECT();
        
		SELECT();
       // Delay();
        		
      //  init_spi_master();
      //  spi_mode(0);

        SPI_Transfer(0b01110000); // write to DAC; buffer out; normal gain; no shutdown; MSB nibble is 0
        SPI_Transfer(0x00); //write the rest.
        DESELECT();
	//	Delay();
		
    }
}

void Delay(void)
{
	volatile unsigned long count = 10000;

	while (count--);
}
