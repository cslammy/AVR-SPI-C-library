/*
 * ad9833.c
 *
 * Created: 2/23/2021 3:16:01 PM
 * make waveforms on AD9833 SPI FG
 */ 
#define F_CPU 16000000UL
#define BAUD 9600
#define BAUD_TOL 2
#include <avr/io.h>
#include "spi3.h"

 uint8_t SPI_TransferTx16(char a, char b);

//check SPI3.h to make sure SPI pins are correctly identified.
uint8_t z = 0;

int main(void)
{
SELECT();
init_spi_master();
spi_mode(2);
 
SPI_TransferTx16(33,0); //reset
SPI_TransferTx16(255,255); //freq Lower
SPI_TransferTx16(0,0); // freq upper
SPI_TransferTx16(207,0); //phase
SPI_TransferTx16(32,0); //sine waveform
 



    /* Replace with your application code */
    while (1) 
    {
    }
}

uint8_t SPI_TransferTx16(char a, char b)
{
	char x;
	SELECT();
	x = SPI_Transfer(a);
	DESELECT();
	SELECT();
	x = SPI_Transfer(b);
	DESELECT();
	return x;

}

